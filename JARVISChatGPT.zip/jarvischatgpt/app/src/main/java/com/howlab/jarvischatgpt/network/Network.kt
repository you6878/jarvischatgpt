package com.howlab.jarvischatgpt.network

import retrofit2.Call
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.http.Body
import retrofit2.http.Headers
import retrofit2.http.POST

data class CompletionResponse(val choices: List<Choice>)
data class Choice(val text: String)
data class ChatRequest(
    val model: String,
    val prompt: String,
    val max_tokens: Int = 4000,
    val temperature: Int = 0
)

// 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

interface OpenAiApi {

    @Headers("Authorization: Bearer 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")
    @POST("v1/completions")
    fun getCompletion(@Body chatRequest: ChatRequest): Call<CompletionResponse>

    companion object {

        private var instance: OpenAiApi? = null

        fun getInstance(): OpenAiApi {
            if (instance != null) {
                return Retrofit.Builder()
                    .baseUrl("https://api.openai.com/")
                    .addConverterFactory(GsonConverterFactory.create())
                    .build()
                    .create(OpenAiApi::class.java)
            }

            return instance!!
        }
    }
}